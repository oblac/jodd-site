CATALINA_HOME=./tomcat

chmod 731 ./tomcat/bin/*.sh

./tomcat/bin/startup.sh
