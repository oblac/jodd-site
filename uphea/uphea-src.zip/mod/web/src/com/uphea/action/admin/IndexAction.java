package com.uphea.action.admin;

import jodd.madvoc.meta.Action;
import jodd.madvoc.meta.MadvocAction;

@MadvocAction
public class IndexAction {

	@Action
	public void view() {
	}
}
