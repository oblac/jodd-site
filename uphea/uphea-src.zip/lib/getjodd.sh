cp ~/prj/oblac/jodd/distribution/build/lib/jodd-3.4.5-SNAPSHOT.jar jodd
cp ~/prj/oblac/jodd/jodd-joy/build/libs/jodd-joy-3.4.5-SNAPSHOT.jar jodd
echo "Done!"
say -v Vicki "Done. Enjoy!"
